<?php

namespace App\Http\Controllers;
use App\Models\Cart;
use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use App\Models\Wishlist;
use Illuminate\Support\Facades\Auth;

use Session;
use Stripe;

use Illuminate\Http\Request;

class HomeController extends Controller
{



    public function index()
    {
        $category=Category::all();
        $data=Product::paginate(9);
        return view ('user.pages.userHome',compact('data','category'));
    }



    public function redirect()
    {
        if(Auth::check()) {
            $usertype = Auth::user()->usertype;

            if($usertype == '1') {
                $total_product = Product::all()->count();
                $total_order = Order::all()->count();
                $total_customer = User::where('usertype', '0')->count();
                $total_revenue = Order::where('delivery_status', '!=', 'Order Cancelled')->sum('price');
                $order_delivered = Order::where('delivery_status', 'Delivered')->count();
                $order_pending = Order::where('delivery_status', 'Processing')->count();

                return view('admin.pages.home', compact('total_product', 'total_order', 'total_customer', 'total_revenue',  'order_delivered', 'order_pending'));
            } else {
                $category = Category::all();
                $data = Product::paginate(9);

                return view('user.pages.userHome', compact('data', 'category'));
            }
        } else {
            // User is not logged in, redirect to login
            return redirect()->route('login'); // Adjust 'login' with your actual login route name
        }
    }




    public function loginUser(Request $request)
        {
            $credentials = $request->validate([
                'email' => ['required', 'email'],
                'password' => ['required'],
            ]);

            if (Auth::attempt($credentials)) {
             $user = Auth::user();

                // Check if the user's usertype is "0"
                if ($user->usertype == 0) {
                    return redirect()->route('redirect');
             } else {
                 Auth::logout(); // Logout the user if usertype is not "0"
                 return redirect()->route('login')->withErrors(['error' => 'Incorrect Username or Password']);
              }
         } else {
               return redirect()->route('login')->withErrors(['error' => 'Incorrect Username or Password']);
         }
        }



        function logoutUser(){
            Auth::guard('web')->logout();
            return redirect('/');
        }



        public function product_details($id)
        {
        $data = Product::find($id);

            // Fetch only the wishlist items that have the same product_id as the current product
            $wishlist = Wishlist::where('product_id', $id)->get();

            return view('user.pages.product_details', compact('data', 'wishlist'));
        }


        public function add_cart(Request $request, $id)
        {
            if (Auth::id() && Auth::user()->usertype == 0) {
                $user = Auth::user();
                $product = Product::find($id);

                if (!$product) {
                    // Handle case where product with given $id is not found
                    return redirect()->back()->with('error', 'Product not found.');
                }

                if ($product->quantity < $request->quantity) {
                    // Handle case where requested quantity exceeds available stock
                    return redirect()->back()->with('error', 'Insufficient stock.');
                }

                // Calculate the price based on the discounted price or regular price
                $price = ($product->discount_price != null) ? $product->discount_price * $request->quantity : $product->price * $request->quantity;

                // Create a new cart item
                $cartItem = new Cart;
                $cartItem->user_id = $user->id;
                $cartItem->product_id = $product->id;
                $cartItem->name = $user->name;
                $cartItem->email = $user->email;
                $cartItem->phone = $user->phone;
                $cartItem->address = $user->address;
                $cartItem->product_title = $product->title;
                $cartItem->quantity = $request->quantity;
                $cartItem->price = $price;
                $cartItem->image = $product->image;

                // Save the cart item to the database
                $cartItem->save();

                // Subtract the quantity from the product table

                $product->save();

                return redirect()->back()->with('success', 'Product added to cart successfully.');
            } else {
                return redirect('login');
            }
        }



        public function show_cart()
        {
            $id=Auth::user()->id;
            $data = Cart::where('user_id' , '=' , $id)->get();
            return view('user.pages.cart',compact('data'));
        }


        public function remove_cart($id)
        {
            $data=Cart::find($id);
            $data->delete();
            return redirect()->back()->with('success', 'Product Deleted from cart successfully.');
        }

        public function cash_order()
        {
            $id=Auth::user()->id;
            $data=Cart::where('user_id' , '=' , $id)->get();



            foreach($data as $data)
            {
                $order=new Order;

                $order->user_id = $data->user_id;
                $order->product_id = $data->product_id;
                $order->name = $data->name;
                $order->email = $data->email;
                $order->phone = $data->phone;
                $order->address = $data->address;
                $order->title = $data->product_title;
                $order->quantity = $data->quantity;
                $order->price = $data->price;
                $order->image = $data->image;
                $order->payment_status ='Cash on Delivery';
                $order->delivery_status ='Processing';

                $order->save();



                $product = Product::find($order->product_id);

                // Update the product quantity
                if ($product) {
                    $product->quantity -= $order->quantity;
                    $product->save();

                }


                $data->delete();

            }

            return redirect()->back()->with('success', 'Order Successful');



        }



        public function stripe($totalprice)
        {
            return view('user.pages.stripe',compact('totalprice'));
        }


        public function stripePost(Request $request, $totalprice)
    {

        Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));

        Stripe\Charge::create ([
                "amount" => $totalprice * 100,
                "currency" => "lkr",
                "source" => $request->stripeToken,
                "description" => "Payment Received"
        ]);




        $id=Auth::user()->id;
        $data=Cart::where('user_id' , '=' , $id)->get();



            foreach($data as $data)
            {
                $order=new Order;

                $order->user_id = $data->user_id;
                $order->product_id = $data->product_id;
                $order->name = $data->name;
                $order->email = $data->email;
                $order->phone = $data->phone;
                $order->address = $data->address;
                $order->title = $data->product_title;
                $order->quantity = $data->quantity;
                $order->price = $data->price;
                $order->image = $data->image;
                $order->payment_status ='Payment Received';
                $order->delivery_status ='Processing';

                $order->save();



                $product = Product::find($order->product_id);

                // Update the product quantity
                if ($product) {
                    $product->quantity -= $order->quantity;
                    $product->save();

                }


                $data->delete();

            }




        Session::flash('success', 'Payment successful!');

        return back();
    }



    public function show_products_here()
    {
        $category=Category::all();
        $data=Product::all();
        return view('user.pages.products', compact('data','category'));
    }

    public function show_wishlist_here()
    {
        // Check if the user is logged in
        if (!auth()->check()) {
            // If not logged in, redirect to the login page
            return redirect()->route('login');
        }

        // Get the current user's wishlist products
        $wishlistProducts = auth()->user()->wishlist->pluck('product_id');

        // Get the products based on the wishlist product IDs
        $data = Product::whereIn('id', $wishlistProducts)->get();

        // Get all categories
        $category = Category::all();

        return view('user.pages.wishlist', compact('data', 'category'));
    }




    public function show_order_here()
    {
        $user_id = Auth::check() ? Auth::user()->id : null; // Check if user is logged in
        $data = $user_id ? Order::where('user_id', $user_id)->get() : collect(); // Use ternary operator to handle the case when the user is not logged in
        return view('user.pages.order', compact('data'));
    }


    public function cancel_order($id)
    {
    // Find the order
            $order = Order::find($id);

        // Check if the order exists
        if (!$order) {
            // Handle case where order is not found
            return redirect()->back()->with('error', 'Order not found');
        }

        // Update order status
        $order->payment_status = 'Order Cancelled';
        $order->delivery_status = 'Order Cancelled';
        $order->save();

        // Find the related product
        $product = Product::find($order->product_id);

        // Check if the product exists
        if (!$product) {
            // Handle case where product is not found
            return redirect()->back()->with('error', 'Product not found');
        }

        // Increment the product quantity
        $product->quantity += $order->quantity;
        $product->save();

        return redirect()->back()->with('success', 'Order cancelled successfully');
    }




    public function product_search(Request $request)

    {

        $category = Category::all();
        $searchtext = $request->search;

            $data = Product::where('title', 'LIKE', "%$searchtext%")

                 ->orWhere('category', 'LIKE', "%$searchtext%")

                 ->paginate(9);


            return view('user.pages.userHome', compact('data', 'category'));
    }


    public function product_search2(Request $request)

    {

        $category = Category::all();
        $searchtext = $request->search;

            $data = Product::where('title', 'LIKE', "%$searchtext%")

                 ->orWhere('category', 'LIKE', "%$searchtext%")

                 ->paginate(9);


            return view('user.pages.products', compact('data', 'category'));
    }







    public function addToWishlist(Request $request, $productId)
    {
        // Check if the user is authenticated
        if (!Auth::check()) {
            // User is not logged in, redirect to login
            return redirect()->route('login')->with('status', 'Please log in to add products to your wishlist');
        }

        $user = Auth::user();

        // Check if the product is already in the wishlist
        if ($user->wishlist()->where('product_id', $productId)->exists()) {
            return redirect()->back()->with('status', 'Product is already in your wishlist');
        }

        // Get the product details from the Products table
        $product = Product::findOrFail($productId);

        // Create a new wishlist entry
        Wishlist::create([
            'title' => $product->title,
            'description' => $product->description,
            'image' => $product->image,
            'category' => $product->category,
            'quantity' => $product->quantity,
            'price' => $product->price,
            'discount_price' => $product->discount_price,
            'product_id' => $product->id,
            'user_id' => $user->id,
        ]);

        return redirect()->back()->with('status', 'Product added to wishlist successfully');
    }


    public function delete_wishlist($id)
    {

        $currentUserId = auth()->id();

        $wishlistEntry = Wishlist::where('product_id', $id)
            ->where('user_id', $currentUserId)
            ->first();

        if ($wishlistEntry) {
            // If the entry exists, delete it
            $wishlistEntry->delete();

            // Redirect to the specified route
            return redirect()->back()->with('success', 'Wishlist entry deleted successfully');
        } else {
            // Wishlist entry not found, you can handle this accordingly
            return response()->json(['message' => 'Wishlist entry not found'], 404);
        }

    }






}
