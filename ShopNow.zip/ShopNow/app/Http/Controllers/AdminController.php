<?php

namespace App\Http\Controllers;
use App\Models\Order;
use App\Models\Product;
use Dompdf\Dompdf;
use Illuminate\Support\Facades\Auth;


use Barryvdh\DomPDF\Facade;

use Illuminate\Http\Request;

class AdminController extends Controller
{



    public function adminIndex()
    {
        return view('admin.login');
    }


    public function loginAdmin(Request $request)
        {
            $credentials = $request->validate([
                'email' => ['required', 'email'],
                'password' => ['required'],
            ]);

            if (Auth::attempt($credentials)) {
             $user = Auth::user();

                // Check if the user's usertype is "0"
                if ($user->usertype == 1) {
                    return redirect()->route('redirect');
             } else {
                 Auth::logout(); // Logout the user if usertype is not "0"
                 return redirect()->route('adminIndex')->withErrors(['error' => 'Incorrect Username or Password']);
              }
         } else {
               return redirect()->route('adminIndex')->withErrors(['error' => 'Incorrect Username or Password']);
         }
        }


        public function show_order()
        {
            if (Auth::check() && Auth::user()->usertype == 1) {
            $data = Order::where('delivery_status', 'Processing')->get();
            return view('admin.pages.show-order', compact('data'));
            }else{
                return abort(403, 'Unauthorized access');
            }
        }


        public function updatestatus($id)
        {
            $data=Order::find($id);

            $data->delivery_status= "Delivered";

            $data->payment_status= "Payment Received";

            $data->save();

            return redirect()->back();
        }


        public function delivered_order()
        {
            if (Auth::check() && Auth::user()->usertype == 1) {

            $data = Order::where('delivery_status', 'Delivered')->get();
            return view('admin.pages.delivered_order', compact('data'));

            }else{

                return abort(403, 'Unauthorized access');

            }
        }

        public function cancelled_order()
        {
            if (Auth::check() && Auth::user()->usertype == 1) {
            $data = Order::where('delivery_status', 'Order Cancelled')->get();
            return view('admin.pages.cancelled-order', compact('data'));
            }else{
                return abort(403, 'Unauthorized access');
            }
        }


        public function searchdata(Request $request)
        {
            $searchtext = $request->search;

            $data = Order::where('name', 'LIKE', "%$searchtext%")
                 ->where('delivery_status', 'Processing')
                 ->orWhere('title', 'LIKE', "%$searchtext%")
                 ->where('delivery_status', 'Processing')
                 ->orWhere('title', 'LIKE', "%$searchtext%")
                 ->where('delivery_status', 'Processing')
                 ->orWhere('payment_status', 'LIKE', "%$searchtext%")
                 ->where('delivery_status', 'Processing')
                 ->orWhere('email', 'LIKE', "%$searchtext%")
                 ->where('delivery_status', 'Processing')
                 ->orWhere('address', 'LIKE', "%$searchtext%")
                 ->where('delivery_status', 'Processing')
                 ->get();


            return view('admin.pages.show-order', compact('data'));
        }


        public function searchdata2(Request $request)
        {
            $searchtext = $request->search;

            $data = Order::where('name', 'LIKE', "%$searchtext%")
                 ->where('delivery_status', 'Delivered')
                 ->orWhere('title', 'LIKE', "%$searchtext%")
                 ->where('delivery_status', 'Delivered')
                 ->orWhere('title', 'LIKE', "%$searchtext%")
                 ->where('delivery_status', 'Delivered')
                 ->orWhere('payment_status', 'LIKE', "%$searchtext%")
                 ->where('delivery_status', 'Delivered')
                 ->orWhere('email', 'LIKE', "%$searchtext%")
                 ->where('delivery_status', 'Delivered')
                 ->orWhere('address', 'LIKE', "%$searchtext%")
                 ->where('delivery_status', 'Delivered')
                 ->get();


            return view('admin.pages.delivered_order', compact('data'));
        }


        public function searchdata3(Request $request)
        {
            $searchtext = $request->search;

            $data = Product::where('title', 'LIKE', "%$searchtext%")

                 ->orWhere('category', 'LIKE', "%$searchtext%")

                 ->get();


            return view('admin.pages.show-product', compact('data'));
        }








}
