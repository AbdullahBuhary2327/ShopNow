<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\AdminController;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {


        $data = User::where('usertype', 0)->get();
        return view('admin.pages.customer',compact('data'));


    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validate the request data
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'phone' => 'required|string|max:15',
            'address' => 'required|string|max:255',
            'password' => 'required|string|min:8',
        ]);

        // Create a new User instance
        $data = new User;

        // Assign values from the request
        $data->name = $request->name;
        $data->email = $request->email;
        $data->phone = $request->phone;
        $data->address = $request->address;

        // Hash the password before saving it to the database
        $data->password = Hash::make($request->password);

        // Save the user data
        $data->save();

        return redirect()->back()->with('success', 'User created successfully!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        

        $data=User::find($id);
        return view('admin.pages.customer-update', compact('data'));


    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $data=User::find($id);

        $data->name=$request->name;
        $data->email=$request->email;
        $data->phone=$request->phone;
        $data->address=$request->address;

        $data->save();

        return redirect()->back();
    }

    public function update_password(Request $request, $id)
    {
        $data=User::find($id);


        $data->password = Hash::make($request->password);

        $data->save();

        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $data=User::find($id);
        $data->delete();
        return redirect()->back();
    }
}
