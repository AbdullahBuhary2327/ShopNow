<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        

        $data=Category::all();
        return view('admin.pages.add-product',compact('data'));

    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = new Product;

        $image=$request->image;

        $imagename=time().'.'.$image->getClientOriginalExtension();
                    $request->image->move('productimage',$imagename);

        $data->image=$imagename;

        $data->title = $request->title;
        $data->description = $request->description;
        $data->category = $request->category;
        $data->quantity = $request->quantity;
        $data->price = $request->price;
        $data->discount_price = $request->discount;

        $data->save();

        return redirect()->back();
    }

    /**
     * Display the specified resource.
     */
    public function show()
    {


        $data=Product::all();
        return view('admin.pages.show-product',compact('data'));


    }

    public function view_update_product($id)
    {


        $item=Category::all();
        $data=Product::find($id);
        return view("admin.pages.update-product", compact("data","item"));


    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $data=Product::find($id);

        $data->title=$request->title;
        $data->description=$request->description;
        $data->category=$request->category;
        $data->quantity=$request->quantity;
        $data->price=$request->price;
        $data->discount_price=$request->discount;

        $data->save();

        return redirect()->back();
    }

    public function update_image(Request $request, $id)
    {
        $data=Product::find($id);

        $image=$request->image;

        $imagename=time().'.'.$image->getClientOriginalExtension();
                    $request->image->move('productimage',$imagename);

        $data->image=$imagename;

        $data->save();

        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $data=Product::find($id);


        $data->delete();


        return redirect()->back();


    }


}








