<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validate the request data
        $request->validate([
            'category_name' => 'required|unique:categories|max:255',
        ]);

        // Check if the category already exists
        $existingCategory = Category::where('category_name', $request->category_name)->first();

        if ($existingCategory) {
            // Category with the same name already exists
            return redirect()->back()->with('error', 'Category Already Exists');
        }

        // Create a new category
        $data = new Category;
        $data->category_name = $request->category_name;
        $data->save();

        return redirect()->back()->with('message', 'Category Added Successfully');
    }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $data=category::find($id);
        $data->delete();
        return redirect()->back();
    }



    public function view_category()
    {





            $data=category::all();
            return view('admin.pages.category',compact('data'));




    }
}
