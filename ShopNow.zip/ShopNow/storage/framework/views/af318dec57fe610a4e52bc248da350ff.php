<section class="product_section layout_padding">
    <div class="container">
       <div class="heading_container heading_center" style="margin-bottom: 50px">
          <h2>
             Our <span>products</span>
          </h2>
       </div>


       <div class="product_section_search">


        <form action="<?php echo e(url('product_search2')); ?>" method="GET">
            <?php echo csrf_field(); ?>

            <select name="search">
                <option selected></option>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->category_name); ?>"><?php echo e($category->category_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <input type="submit" value="Search">
        </form>


       </div>


       <div class="row">


        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


          <div class="col-sm-6 col-md-4 col-lg-4">
             <div class="box">
                <div class="option_container">
                   <div class="options">
                      <a href="<?php echo e(url('product_details', $data->id)); ?>" class="option1">
                      Product Details
                      </a>


                      <form action="<?php echo e(url('add_cart',$data->id)); ?>" method="Post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="number" name="quantity" class="op-q" value="1" min="1" max="<?php echo e($data->quantity); ?>">
                        <input type="submit" value="add to cart">
                      </form>



                   </div>
                </div>
                <div class="img-box">
                    <img  name="image" src="<?php echo e(asset('productimage/' . $data->image)); ?>" alt="Job 1 Image">
                </div>
                <div class="detail-box">
                   <h5>
                      <?php echo e($data->title); ?>

                   </h5>
                   <?php if($data->discount_price!=null): ?>
                   <h6 style="margin-left: 20px; margin-right: 30px; color: red;">
                    <?php echo e($data->discount_price); ?>

                 </h6>

                 <h6 style="text-decoration: line-through; color: blue;">
                    <?php echo e($data->price); ?>

                 </h6>

                 <?php else: ?>

                 <h6 style="color: blue;">
                    <?php echo e($data->price); ?>

                 </h6>


                   <?php endif; ?>

                </div>
             </div>
          </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




       </div>

    </div>
 </section>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/user/components/main_product_view.blade.php ENDPATH**/ ?>