<?php if(session('success')): ?>
    <div class="alert alert-success" id="success-message">
        <?php echo e(session('success')); ?>

    </div>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>
        $(document).ready(function () {
            // Close the success message after 5 seconds (adjust the time as needed)
            setTimeout(function () {
                $('#success-message').fadeOut('fast');
            }, 2500);
        });
    </script>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger" id="error-message">
        <?php echo e(session('error')); ?>

    </div>
    <script>
        $(document).ready(function () {
            // Close the error message after 5 seconds (adjust the time as needed)
            setTimeout(function () {
                $('#error-message').fadeOut('fast');
            }, 2500);
        });
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/user/components/session.blade.php ENDPATH**/ ?>