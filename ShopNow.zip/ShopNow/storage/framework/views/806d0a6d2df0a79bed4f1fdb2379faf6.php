<div class="info-boxes-sec">

<div class="info-boxes">
    <div class="info-box">
        <i class="fas fa-cubes"></i>
        <h3>Total Products</h3>
        <p><?php echo e($total_product); ?></p>
    </div>
    <div class="info-box">
        <i class="fas fa-shopping-cart"></i>
        <h3>Total Orders</h3>
        <p><?php echo e($total_order); ?></p>
    </div>
    <div class="info-box">
        <i class="fas fa-users"></i>
        <h3>Total Customers</h3>
        <p><?php echo e($total_customer); ?></p>
    </div>

</div>

<div class="info-boxes">

    <div class="info-box">
        <i class="fas fa-dollar-sign"></i>
        <h3>Total Revenue</h3>
        <p><?php echo e($total_revenue); ?></p>
    </div>


    <div class="info-box">
        <i class="fas fa-check-circle"></i>
        <h3>Order Delivered</h3>
        <p><?php echo e($order_delivered); ?></p>
    </div>
    <div class="info-box">
        <i class="fas fa-hourglass-half"></i>
        <h3>Order Pending</h3>
        <p><?php echo e($order_pending); ?></p>
    </div>
</div>


</div>





<h6>.</h6>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/admin/components/infobox.blade.php ENDPATH**/ ?>