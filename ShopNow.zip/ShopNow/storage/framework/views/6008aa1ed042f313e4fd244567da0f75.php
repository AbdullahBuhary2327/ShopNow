<div class="title-category">
    <h1>Pending Orders</h1>
</div>


<div class="search_button_section">
    <form action="<?php echo e(url('search')); ?>" method="GET">

        <?php echo csrf_field(); ?>

        <input type="text" name="search" placeholder="Search Here">
        <input type="submit" value="Search">
    </form>
</div>

<div class="modern-table-4" style="margin-left: 30px">
    <table class="data-table-4">
        <thead>
            <tr>

                <th>Customer Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Payment Status</th>
                <th>Delivery Status</th>
                <th>Image</th>
                <th style="width: 100px;">Delivered</th>
            </tr>
        </thead>
        <tbody>



            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>



            <tr>
                <td><?php echo e($data->name); ?></td>
                <td><?php echo e($data->email); ?></td>
                <td><?php echo e($data->phone); ?></td>
                <td><?php echo e($data->address); ?></td>
                <td><?php echo e($data->title); ?></td>
                <td><?php echo e($data->quantity); ?></td>
                <td><?php echo e($data->price); ?></td>
                <td><?php echo e($data->payment_status); ?></td>
                <td><?php echo e($data->delivery_status); ?></td>
                <td><img src="<?php echo e(asset('productimage/' . $data->image)); ?>" width="100px" height="100px"></td>
                <?php if($data->delivery_status == 'Processing'): ?>
                {
                <td style="width: 150px;">

                        <button class="btn btn-danger"><a onclick="return confirm('Are You Sure The <?php echo e($data->title); ?> is Delivered')"
                            href="<?php echo e(url('/updatestatus',$data->id)); ?>" >Delivered?</a></button>
                </td>
                }

                <?php else: ?>
                {
                    <td style="width: 150px;"><img width="50px" style="margin-left: 20px;" src="<?php echo e(asset('yes.png')); ?>" alt=""></td>
                }

                <?php endif; ?>



            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr><td colspan="16">No Data Found</td></tr>

            <?php endif; ?>


        </tbody>
    </table>
</div>










<h6>.</h6>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/admin/components/order/show.blade.php ENDPATH**/ ?>