<div class="title-category">
    <h1>Update Customers</h1>
</div>

<div class="sesseion-msg">

<?php if(session('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger"> <!-- Changed to alert-danger for error messages -->
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

</div>


<div class="category-form">
    <form action="<?php echo e(route('update-user',$data->id)); ?>" method="POST" >
        <?php echo csrf_field(); ?>

        <label for="name">Name</label>
        <input type="text" id="name" name="name" value="<?php echo e($data->name); ?>" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?php echo e($data->email); ?>" required>

        <label for="phone">Phone</label>
        <input type="number" id="phone" name="phone" value="<?php echo e($data->phone); ?>" required>

        <label for="address">Address</label>
        <input type="text" id="address" name="address" value="<?php echo e($data->address); ?>" required>





        <button type="submit">Update User</button>
    </form>
</div>

<h1 style="text-align: center; margin-top: 80px;">Update Password</h1>
<div class="category-form">
    <form action="<?php echo e(route('update-user-password',$data->id)); ?>" method="POST" >
        <?php echo csrf_field(); ?>

        <label for="cpassword">Current Password</label>
        <input type="text" id="cpassword" name="cpassword" value="<?php echo e($data->password); ?>" disabled>

        <label for="password">New Password</label>
        <input type="text" id="password" name="password" placeholder="Enter New Password" required>







        <button type="submit">Update Password</button>
    </form>
</div>







<h6>.</h6>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/admin/components/customer/update.blade.php ENDPATH**/ ?>