<div class="title-category">
    <h1>Cancelled Orders</h1>
</div>



<div class="modern-table-4" style="margin-left: 30px">
    <table class="data-table-4">
        <thead>
            <tr>

                <th>Customer Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Payment Status</th>
                <th>Delivery Status</th>
                <th>Image</th>
            </tr>
        </thead>
        <tbody>



            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>



            <tr>
                <td><?php echo e($data->name); ?></td>
                <td><?php echo e($data->email); ?></td>
                <td><?php echo e($data->phone); ?></td>
                <td><?php echo e($data->address); ?></td>
                <td><?php echo e($data->title); ?></td>
                <td><?php echo e($data->quantity); ?></td>
                <td><?php echo e($data->price); ?></td>
                <td style="color: red;"><?php echo e($data->payment_status); ?></td>
                <td style="color: red;"><?php echo e($data->delivery_status); ?></td>
                <td><img src="<?php echo e(asset('productimage/' . $data->image)); ?>" width="100px" height="100px"></td>




            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr><td colspan="16">No Data Found</td></tr>

            <?php endif; ?>


        </tbody>
    </table>
</div>










<h6>.</h6>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/admin/components/order/cancelled.blade.php ENDPATH**/ ?>