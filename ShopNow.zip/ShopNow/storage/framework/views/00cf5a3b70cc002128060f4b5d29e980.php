<div class="title-category">
    <h1>Add Categories</h1>
</div>

<div class="sesseion-msg">

<?php if(session('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger"> <!-- Changed to alert-danger for error messages -->
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

</div>


<div class="category-form">
    <form action="<?php echo e(route('add-category')); ?>" method="POST" >
        <?php echo csrf_field(); ?>

        <label for="category_name">Category Name</label>
        <input type="text" id="category_name" name="category_name" placeholder="Enter category name" required>



        <button type="submit">Add Category</button>
    </form>
</div>



<div class="modern-table" style="margin-top: 50px;">
    <table class="data-table-2">
        <thead>
            <tr>

                <th>Category Name</th>

                <th style="width: 110px">Delete</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <tr>
                <td><?php echo e($data->category_name); ?></td>
                <td><a onclick="return confirm('Are You Sure You Want To Delete <?php echo e($data->category_name); ?>')" href="<?php echo e(route('delete-category',$data->id)); ?>" class="btn btn-danger" style="width: 80%;">Delete</a></td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- Add more rows as needed -->
        </tbody>
    </table>
</div>




<h6>.</h6>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/admin/components/Category/main.blade.php ENDPATH**/ ?>