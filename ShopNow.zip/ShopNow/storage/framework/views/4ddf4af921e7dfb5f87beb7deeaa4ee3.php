<div class="title-category">
    <h1>Update Product</h1>
</div>


<div class="category-form" style="margin-bottom: 100px;">
    <form action="<?php echo e(route('update-product',$data->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <label for="title">Product Name</label>
        <input type="text" id="title" name="title" value="<?php echo e($data->title); ?>" required>

        <label for="description">Product Description</label>
        <input type="text" id="description" name="description" value="<?php echo e($data->description); ?>" required>

        <label for="category">Category Name</label>
        <select id="category" name="category" required>
            <option value="<?php echo e($data->category); ?>" selected=""><?php echo e($data->category); ?></option>
            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->category_name); ?>"><?php echo e($item->category_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

        <label for="quantity">Product quantity</label>
        <input type="number" id="quantity" name="quantity" value="<?php echo e($data->quantity); ?>" required>

        <label for="price">Product Price</label>
        <input type="number" id="price" name="price" value="<?php echo e($data->price); ?>" required>

        <label for="discount">Discount</label>
        <input type="number" id="discount" name="discount" value="<?php echo e($data->discount_price); ?>">





        <button type="submit">Update Product</button>
    </form>
</div>

<div class="title-category">
    <h1>Update Product Image</h1>
</div>

<div class="category-form">
    <form action="<?php echo e(route('update-product-image',$data->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <label for="image">Old Image:</label>
    <img width="250px" src="/productimage/<?php echo e($data->image); ?>" alt="" style="margin-bottom: 20px">

    <label for="image">New Image:</label>
    <input type="file" id="image" name="image" value="<?php echo e($data->image); ?>" required>


        <button type="submit">Update Image</button>
    </form>
</div>


<h6 style="margin-top: 100px;">.</h6>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/admin/components/add/update.blade.php ENDPATH**/ ?>