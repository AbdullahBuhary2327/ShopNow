<style>
    /* Reset some default styles */
    body, h1, h2, h3, p, ul, li, figure, img, form, button {
        margin: 0;
        padding: 0;
        border: 0;
    }

    body {
        font-family: 'Arial', sans-serif;
    }

    .header_section {
        background-color: #cfcfcf74;
        color: #000000;
        padding: 10px 0;
    }

    .container {
        width: 80%;
        margin: 0 auto;
    }

    .navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .navbar-brand img {
        max-width: 100%;
        height: auto;
    }

    .navbar-toggler {
        display: none;
    }

    .navbar-nav {
        display: flex;
        list-style: none;
        margin-left: auto;
    }

    .nav-item {
        margin-right: 15px;
    }

    .nav-link {
        color: #000000;
        text-decoration: none;
        padding: 10px;
        display: block;
        margin-top: 30px;
        font-size: 20px;
        margin-bottom: 30px;

    }

    .nav-link:hover {
        color: rgb(255, 55, 55);
    }

    .nav_search-btn {
        background-color: #cfcfcf00;
        color: #000000;
        border: none;
        padding: 8px 15px;
        margin-top: 40px;
        cursor: pointer;
    }

    .dropdown {
        position: relative;
    }

    .dropdown-toggle::after {
        content: '\25BC';
        margin-left: 5px;
    }

    .dropdown-menu {
        display: none;
        position: absolute;
        padding: 10px;
    }

    .dropdown:hover .dropdown-menu {
        display: block;
    }

    /* Additional styles for login/register buttons */
    .btn-primary, .btn-success {
        background-color: #007bff;
        color: #fff;
        text-decoration: none;
        padding: 10px 15px;
        border: none;
        border-radius: 5px;
    }

    .btn-primary:hover, .btn-success:hover {
        color: #ff1414;rgb(179, 0, 0)rgb(255, 58, 58);
    }



</style>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/user/components/stripe/navbarstyle.blade.php ENDPATH**/ ?>