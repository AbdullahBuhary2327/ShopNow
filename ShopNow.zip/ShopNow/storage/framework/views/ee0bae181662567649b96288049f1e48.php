<script>
    $(document).ready(function() {
        // Toggle nested links on click
        $('.sidebar > ul > li').click(function() {
            $(this).toggleClass('active');
            $(this).find('.nested-links').slideToggle();
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/admin/components/script.blade.php ENDPATH**/ ?>