<header class="header_section">
    <div class="container">
        <nav class="navbar">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img width="250" src="home/images/shopnow-logo2.png"
                    alt="#" /></a>
            <button class="navbar-toggler" type="button" aria-label="Toggle navigation"></button>
            <div class="navbar-nav">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>">Home </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('show_products_here')); ?>">Products</a>
                    </li>


                    <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('show_cart')); ?>">Cart</a>
                    </li>

                    <?php endif; ?>

                    <?php endif; ?>

                    <form class="form-inline">
                        <button class="btn my-2 my-sm-0 nav_search-btn" type="submit">
                            <i class="fa fa-search" aria-hidden="true"></i>
                        </button>
                    </form>




                </ul>
            </div>
        </nav>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/user/components/stripe/header.blade.php ENDPATH**/ ?>