<div class="title-category">
    <h1>Show Product</h1>
</div>


<div class="search_button_section">
    <form action="<?php echo e(url('search3')); ?>" method="GET">

        <?php echo csrf_field(); ?>

        <input type="text" name="search" placeholder="Search Here">
        <input type="submit" value="Search">
    </form>
</div>


<div class="modern-table-6">
    <table class="data-table-6">
        <thead>
            <tr>

                <th>Product Name</th>
                <th style="width: 200px;">Product Description</th>
                <th>Product Image</th>
                <th>Category Name</th>
                <th>Quantity</th>
                <th>Product Price</th>
                <th>Discounted Price</th>
                <th style="width: 210px">Update</th>
                <th style="width: 210px">Delete</th>
            </tr>
        </thead>
        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>


            <tr>
                <td><?php echo e($data->title); ?></td>
                <td><?php echo e($data->description); ?></td>
                <td><img src="<?php echo e(asset('productimage/' . $data->image)); ?>" width="100px" height="100px"></td>
                <td><?php echo e($data->category); ?></td>
                <td><?php echo e($data->quantity); ?></td>
                <td><?php echo e($data->price); ?></td>
                <td><?php echo e($data->discount_price); ?></td>
                <td><a href="<?php echo e(route('view-update-product',$data->id)); ?>" class="btn btn-warning" style="width: 100px;">Update</a></td>
                <td><a onclick="return confirm('Are You Sure You Want To Delete <?php echo e($data->title); ?>')" href="<?php echo e(route('delete-product',$data->id)); ?>" class="btn btn-danger" style="width: 100px;">Delete</a></td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr><td colspan="16">No Data Found</td></tr>

            <?php endif; ?>
            <!-- Add more rows as needed -->
        </tbody>
    </table>
</div>










<h6>.</h6>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/admin/components/add/view.blade.php ENDPATH**/ ?>