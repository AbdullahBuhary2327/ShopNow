<style>
    body {
        margin: 0;
        padding: 0;
        font-family: 'Arial', sans-serif;
        background-color: #f4f4f4;
    }

    .container {
        display: flex;
        height: 100vh;
    }

    .sidebar {
        width: 200px;
    background-color: #333;
    color: #fff;
    padding-top: 20px;
    height: 100%;
    box-sizing: border-box;
    position: fixed; /* Set the position to fixed */
    top: 0; /* Stick it to the top */
    left: 0; /* Align it to the left */
    }

    .sidebar ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .sidebar a {
        text-decoration: none;
        color: #fff;
        padding: 15px;
        display: block;
        transition: background 0.3s ease;
    }

    .sidebar a:hover {
        background-color: #555;
    }

    .sidebar a.active {
        background-color: #555;
    }

    .sidebar a.active-link {
    background-color: #5555557a;
    color: rgb(141, 141, 141);
}

.sidebar a.active-link:hover {
    background-color: #5555557a;
    color: rgb(141, 141, 141); /* Set the text color for the active link */
}

    .main-content {
        flex: 1;
        padding: 20px;
    }

    header {
        background-color: #007bff;
        color: #fff;
        padding: 20px;
        text-align: center;
    }

    section {
        margin-top: 20px;
    }


    .modern-table-1
    {
        margin-top: 80px;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-bottom: 100px;
        margin: 0 auto;
        flex: 1;
        padding: 20px;
        margin-right: 20px;
            margin-left: 200px;
    }

    .data-table {
    width: 100%;
    border-collapse: collapse;
    margin: 5%;
}

.data-table th, .data-table td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: left;
}

.data-table th {
    background-color: #494949;
    color: #fff;
}

.data-table tbody tr:hover {
    background-color: #f5f5f5;
}

.data-table a {
    text-decoration: none;
    color: #500b0b;
}

.data-table a:hover {
    text-decoration: underline;
}

.sidebar a i {
    margin-right: 20px;
    color: #9e9e9e /* Adjust this value as needed */
}




.category-form {
        max-width: 500px;
        margin: 0 auto;
        margin-top: 50px;
    }

    form {
        display: flex;
        flex-direction: column;
    }

    label {
        font-size: 16px;
        margin-bottom: 8px;
        color: #333;
    }

    input, textarea, select {
        padding: 10px;
        margin-bottom: 16px;
        border: 1px solid #ddd;
        border-radius: 5px;
        font-size: 14px;
    }

    button {
        background-color: #555555;
        color: #fff;
        padding: 12px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }

    button:hover {
        background-color: #343434;
    }


    .title-category
    {
        text-align: center;
        margin-bottom: 50px;
        margin-top: 50px;
    }


    .modern-table {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 100px;
    flex: 1;
    padding: 20px;
    margin-right: 20px;
            margin-left: 20px;
}

 .data-table-2 {
    width: 50%;
    border-collapse: collapse;
}

.data-table-2 th, .data-table-2 td {
    border: 1px solid #000000;
    padding: 12px;
    text-align: left;
}

.data-table-2 th {
    background-color: #555;
    color: #fff;
}

.data-table-2 tbody{
    background-color: #ffffff;
}



.data-table-2 a {
    text-decoration: none;
    color: #ffffff;
}

.data-table-2 a:hover {
    text-decoration: underline;
    color: white;
}







.modern-table-3 {
    margin: auto;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 100px;
    flex: 1;
    padding: 20px;
    margin-left: 10px;
}

 .data-table-3 {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.data-table-3 th, .data-table-3 td {
    border: 1px solid #000000;
    padding: 12px;
    text-align: left;
}

.data-table-3 th {
    background-color: #555;
    color: #fff;
}

.data-table-3 tbody{
    background-color: #ffffff;
}



.data-table-3 a {
    text-decoration: none;
    color: #ffffff;
}

.data-table-3 a:hover {
    text-decoration: underline;
    color: white;
}




.modern-table-6 {
    margin: auto;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 100px;
    flex: 1;
    padding: 20px;
    margin-left: 100px;
}

 .data-table-6 {
    width: 80%;
    border-collapse: collapse;
    margin-top: 20px;
}

.data-table-6 th, .data-table-6 td {
    border: 1px solid #000000;
    padding: 12px;
    text-align: left;
}

.data-table-6 th {
    background-color: #555;
    color: #fff;
}

.data-table-6 tbody{
    background-color: #ffffff;
}



.data-table-6 a {
    text-decoration: none;
    color: #ffffff;
}

.data-table-6 a:hover {
    text-decoration: underline;
    color: white;
}





.sesseion-msg
{
    margin: 30px;
    width: 80%;
    font-size: 30px;
}

.nested-links {
    display: none;
}




.modern-table-4 {


margin-bottom: 100px;
flex: 1;
width: 100%;
}

.data-table-4 {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.data-table-4 th, .data-table-4 td {
    border: 1px solid #000000;
    padding: 12px;
    text-align: left;
}

.data-table-4 th {
    background-color: #555;
    color: #fff;
}

.data-table-4 tbody{
    background-color: #ffffff;
}



.data-table-4 a {
    text-decoration: none;
    color: #ffffff;
}

.data-table-4 a:hover {
    text-decoration: underline;
    color: white;
}



.search_button_section {
    text-align: center;
    margin-top: 20px;
}

.search_button_section form {
    display: inline-block;
}

.search_button_section input[type="text"] {
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 4px 0 0 4px;
    outline: none;
    width: 500px
}

.search_button_section input[type="submit"] {
    padding: 10px 15px;
    font-size: 16px;
    background-color: #430404;
    color: #fff;
    border: 1px solid #430404;
    border-radius: 0 4px 4px 0;
    cursor: pointer;
    width: 150px;
    outline: none;
}

.search_button_section input[type="submit"]:hover {
    background-color: #280404;
    border-color: #280404;
}



.info-boxes-sec{

    margin-bottom: 200px;
}



.info-boxes {
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
    margin-top: 30px;
    margin-left: 200px;
    margin-bottom: 50px;
}

.info-box {
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    padding: 20px;
    text-align: center;
    margin-bottom: 20px;
    width: calc(20% - 20px); /* Adjust the width as needed */
}

.info-box i {
    font-size: 40px;
    margin-bottom: 10px;
}

.info-box h3 {
    font-size: 18px;
    margin-bottom: 10px;
}

.info-box p {
    font-size: 16px;
    color: #555;
}





.info-boxes2 {
    display: flex;
    flex-wrap: wrap;
    margin-top: 30px;
    margin-left: 530px;
}

.info-box2 {
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    padding: 20px;
    margin-right: 60px;
    text-align: center;
    margin-bottom: 20px;
    width: calc(30% - 30px); /* Adjust the width as needed */
}

.info-box2 i {
    font-size: 40px;
    margin-bottom: 10px;
}

.info-box2 h3 {
    font-size: 18px;
    margin-bottom: 10px;
}

.info-box2 p {
    font-size: 16px;
    color: #555;
}

































.btn {
  display: inline-block;
  font-weight: 400;
  text-align: center;
  white-space: nowrap;
  vertical-align: middle;
  user-select: none;
  border: 1px solid transparent;
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  line-height: 1.5;
  border-radius: 0.25rem;
  transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

/* Danger button specific styles */
.btn-danger {
  color: #fff;
  background-color: #dc3545;
  border-color: #dc3545;
}

.btn-danger:hover {
  color: #fff;
  background-color: #c82333;
  border-color: #bd2130;
}

.btn-danger:focus, .btn-danger.focus {
  box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.5);
}

.btn-danger.disabled, .btn-danger:disabled {
  background-color: #dc3545;
  border-color: #dc3545;
}

.btn-danger:not(:disabled):not(.disabled):active, .btn-danger:not(:disabled):not(.disabled).active,
.show > .btn-danger.dropdown-toggle {
  background-color: #bd2130;
  border-color: #b21f2d;
}

.btn-danger:not(:disabled):not(.disabled):active:focus, .btn-danger:not(:disabled):not(.disabled).active:focus,
.show > .btn-danger.dropdown-toggle:focus {
  box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.5);
}



/* Success button specific styles */
.btn-success {
  color: #fff;
  background-color: #28a745;
  border-color: #28a745;
}

.btn-success:hover {
  color: #fff;
  background-color: #218838;
  border-color: #1e7e34;
}

.btn-success:focus, .btn-success.focus {
  box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.5);
}

.btn-success.disabled, .btn-success:disabled {
  background-color: #28a745;
  border-color: #28a745;
}

.btn-success:not(:disabled):not(.disabled):active, .btn-success:not(:disabled):not(.disabled).active,
.show > .btn-success.dropdown-toggle {
  background-color: #1e7e34;
  border-color: #1c7430;
}

.btn-success:not(:disabled):not(.disabled):active:focus, .btn-success:not(:disabled):not(.disabled).active:focus,
.show > .btn-success.dropdown-toggle:focus {
  box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.5);
}



/* Updated Warning button specific styles with dark orange color */
.btn-warning {
  color: #212529;
  background-color: #ff8c00; /* Dark Orange */
  border-color: #ff8c00; /* Dark Orange */
}

.btn-warning:hover {
  color: #212529;
  background-color: #e07d00; /* Darker shade of Orange */
  border-color: #d27500; /* Darker shade of Orange */
}

.btn-warning:focus, .btn-warning.focus {
  box-shadow: 0 0 0 0.2rem rgba(255, 140, 0, 0.5); /* Dark Orange */
}

.btn-warning.disabled, .btn-warning:disabled {
  background-color: #ff8c00; /* Dark Orange */
  border-color: #ff8c00; /* Dark Orange */
}

.btn-warning:not(:disabled):not(.disabled):active, .btn-warning:not(:disabled):not(.disabled).active,
.show > .btn-warning.dropdown-toggle {
  background-color: #d27500; /* Darker shade of Orange */
  border-color: #c86e00; /* Darker shade of Orange */
}

.btn-warning:not(:disabled):not(.disabled):active:focus, .btn-warning:not(:disabled):not(.disabled).active:focus,
.show > .btn-warning.dropdown-toggle:focus {
  box-shadow: 0 0 0 0.2rem rgba(255, 140, 0, 0.5); /* Dark Orange */
}







</style>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/admin/components/style.blade.php ENDPATH**/ ?>