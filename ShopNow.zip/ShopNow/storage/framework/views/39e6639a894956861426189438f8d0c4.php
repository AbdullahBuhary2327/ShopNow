<style>
    .search_button_section {
    text-align: center;
    margin-top: 20px;
}

.search_button_section form {
    display: inline-block;
}

.search_button_section input[type="text"] {
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 4px 0 0 4px;
    outline: none;
}

.search_button_section input[type="submit"] {
    padding: 10px 15px;
    font-size: 16px;
    background-color: #007bff;
    color: #fff;
    border: 1px solid #007bff;
    border-radius: 0 4px 4px 0;
    cursor: pointer;
    outline: none;
}

.search_button_section input[type="submit"]:hover {
    background-color: #0056b3;
    border-color: #0056b3;
}
</style>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/admin/components/order/style.blade.php ENDPATH**/ ?>