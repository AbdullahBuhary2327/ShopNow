<div class="cart-container" style="margin-bottom: 50px;">
    <h2>View Your Orders</h2>
    <table class="cart-table">
        <thead>
            <tr>
                <th style="width: 150px;">Product Image</th>
                <th>Product Name</th>
                <th style="width: 250px;">Product Quantity</th>
                <th>Price</th>
                <th>Payment Status</th>
                <th>Delivery Status</th>
                <th>Cancel Order</th>
            </tr>
        </thead>
        <tbody>



            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <tr>
                <td style="text-align: center;"><img src="<?php echo e(asset('productimage/' . $data->image)); ?>" alt="Product Image"></td>
                <td style="text-align: center;"><?php echo e($data->title); ?></td>
                <td style="text-align: center;"><?php echo e($data->quantity); ?></td>
                <td style="text-align: right;"><?php echo e($data->price); ?>.00</td>

                <?php if($data->payment_status=='Payment Received'): ?>

                <td style="text-align: center; font-weight: bold; color: green; text-align:center;"> <?php echo e($data->payment_status); ?></td>

                <?php elseif($data->payment_status == 'Order Cancelled'): ?>

                <td style="text-align: center; font-weight: bold; color: rgb(128, 0, 0); text-align:center;"> <?php echo e($data->payment_status); ?></td>

                <?php else: ?>


                <td style="text-align: center; font-weight: bold; color: rgb(17, 0, 255); text-align:center;"> <?php echo e($data->payment_status); ?></td>

                <?php endif; ?>

                <?php if($data->delivery_status=='Processing'): ?>

                <td style="text-align: center; font-weight: bold; color: rgb(255, 94, 0); text-align:center;"> <?php echo e($data->delivery_status); ?></td>

                <?php elseif($data->delivery_status == 'Order Cancelled'): ?>

                <td style="text-align: center; font-weight: bold; color: rgb(128, 0, 0); text-align:center;"><?php echo e($data->delivery_status); ?></td>

                <?php else: ?>

                <td style="text-align: center; font-weight: bold; color: green; text-align:center;"> <?php echo e($data->delivery_status); ?></td>

                <?php endif; ?>

                <?php if($data->payment_status == 'Cash on Delivery'): ?>



                <td style="text-align: center;"><a onclick="return confirm('Are You Sure You Want To Cancel This Order Of <?php echo e($data->title); ?>')" href="<?php echo e(url('cancel_order',$data->id)); ?>" class="btn btn-danger">Cancel</a></td>


                <?php elseif($data->delivery_status == 'Order Cancelled'): ?>

                <td style="text-align: center; font-weight: bold; color: rgb(128, 0, 0); text-align:center;">Cancelled</td>



                <?php else: ?>

                <td style="text-align: center;">Not Applicable</td>



                <?php endif; ?>

            </tr>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </tbody>
    </table>



</div>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/user/components/order_table_content.blade.php ENDPATH**/ ?>