<div id="product_detail_section" >
    <div class="img-box">
        <img name="image" src="<?php echo e(asset('productimage/' . $data->image)); ?>" alt="Product Image">
    </div>
    <div class="detail-box">
        <h1><?php echo e($data->title); ?></h1>
        <h3>Category: <?php echo e($data->category); ?></h3>
        <p><?php echo e($data->description); ?></p>
        <h6 >Stock: <?php echo e($data->quantity); ?></h6>


        <?php if(Auth::check()): ?>
            <?php if(Auth::user()->wishlist()->where('product_id', $data->id)->exists()): ?>
                <button  class="btn btn-outline-danger" style="width: 300px; color: black;"><a style="color: black" onclick="return confirm('Are You Sure You Want Delete <?php echo e($data->title); ?> From Your Wishlist')" href="<?php echo e(url('delete_wishlist', $data->id)); ?>">Delete From wishlist</a> </button>
            <?php else: ?>
                <form action="<?php echo e(route('wishlist.add', ['product' => $data->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button onclick="return confirm('Are You Sure You Want Add This To Your Wishlist')" type="submit" class="btn btn-outline-success" style="width: 200px; color: black;">Add To Wishlist</button>
                </form>
            <?php endif; ?>
        <?php else: ?>
            <!-- Display a message or redirect to the login page for guests -->
        <?php endif; ?>



        <?php if($data->discount_price!=null): ?>

        <h6 class="discounted">Discounted Price: <?php echo e($data->discount_price); ?></h6>
        <h6 class="price">Price: <?php echo e($data->price); ?></h6>

        <?php else: ?>

        <h6 class="price2">Price: <?php echo e($data->price); ?></h6>

        <?php endif; ?>

        <div style="display: flex; align-items: center;" class="add-to-cart-form">
            <form action="<?php echo e(url('add_cart',$data->id)); ?>" method="Post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="number" name="quantity" class="productQuantity-quan" value="1" min="1" max="<?php echo e($data->quantity); ?>">
                <input type="submit" value="add to cart" class="productQuantity-sub">
              </form>
        </div>


    </div>

</div>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/user/components/productDetail.blade.php ENDPATH**/ ?>