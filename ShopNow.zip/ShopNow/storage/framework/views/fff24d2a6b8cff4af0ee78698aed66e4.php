<div class="title-category">
    <h1>Add Product</h1>
</div>

<div class="sesseion-msg">

<?php if(session('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger"> <!-- Changed to alert-danger for error messages -->
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

</div>


<div class="category-form">
    <form action="<?php echo e(route('add-product')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <label for="title">Product Name</label>
        <input type="text" id="title" name="title" placeholder="Enter Product name" required>

        <label for="description">Product Description</label>
        <input type="text" id="description" name="description" placeholder="Enter Product description" required>

        <label for="image">Product Image</label>
        <input type="file" id="image" name="image" required>

        <label for="category">Category Name</label>
        <select id="category" name="category" required>
            <option value="" selected="">Select a Category</option>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($data->category_name); ?>"><?php echo e($data->category_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

        <label for="quantity">Product quantity</label>
        <input type="number" id="quantity" name="quantity" placeholder="Enter Product quantity" required>

        <label for="price">Product Price</label>
        <input type="number" id="price" name="price" placeholder="Enter Product Price" required>

        <label for="discount">Discount</label>
        <input type="number" id="discount" name="discount" placeholder="Enter Discounted Price">





        <button type="submit">Add Product</button>
    </form>
</div>








<h6>.</h6>




</div>
</div>



<?php echo $__env->make('admin.components.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ShopNow\resources\views/admin/components/add/main.blade.php ENDPATH**/ ?>