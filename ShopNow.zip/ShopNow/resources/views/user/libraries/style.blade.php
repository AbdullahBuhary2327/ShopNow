<style>
    #product_detail_section {
        display: flex;
        margin: 20px 0;
        margin-top: 50px;
        margin-left: 50px;
        justify-content: space-between; /* Add this line */
        width: 80%;
        height: 500px;
    }

    #product_detail_section .img-box {
        flex: 1;
        margin-right: 20px;
        padding-left: 10px;
        padding-right: 10px;
        border: 5px solid #000;
    }

    #product_detail_section .img-box img {
        width: 450px;
        height: auto;

        margin-top: 20px;
    }

    #product_detail_section .detail-box {
        flex: 2;
        display: flex;
        margin-left: 50px;
        flex-direction: column;
        padding-left: 50px;
        padding-right: 50px;
    }

    #product_detail_section .detail-box h1 {
        font-size: 40px;
        margin-top: 30px;
        margin-bottom: 20px;
        font-weight: bold;
    }

    #product_detail_section .detail-box h3 {
        font-size: 20px;
        font-weight: bold;
        margin-bottom: 20px;
    }

    #product_detail_section .detail-box p {
        margin-bottom: 5%;
    }

    #product_detail_section .detail-box .price {
        color: blue;
        margin: 5px 0;
        text-decoration: line-through;
    }

    #product_detail_section .detail-box .price2 {
        color: blue;
        margin: 5px 0;
    }

    #product_detail_section .detail-box h6.discounted {
        color: red;
        margin-bottom: 10px;
    }

    #product_detail_section .detail-box h6 {
        margin: 5px 0;
    }

    #product_detail_section .detail-box button {
        margin-top: 10px;
        margin-bottom: 10px;
        color: white;

    }

    .add-to-cart-form {
        margin-top: 5%;
    }




    .cart-container {
        margin-right: 10%;
        margin-top: 50px;
        margin-left: 10%;
    }

    .cart-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .cart-table th,
    .cart-table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    .cart-container h2{
        font-weight: bolder;
    }

    .cart-table th {
        background-color: #f2f2f2;
    }

    .cart-table img {
        max-width: 80%;
        text-align: center;
        height: auto;
    }

    .cart-table button{
        width: 100px;
        margin: 20px;
    }

    .cart-table button a{
        color: white;
    }


    .cart-container .proceed{
        margin-left: 50px;
        margin-top: 50px;
        text-align: center;
    }

    .cart-container .proceed h1{
        font-size: 20px;
        font-weight: bold;

    }

    .cart-container .proceed a {
        margin-right: 20px;
        margin-top: 10px;
    }




    .product_section_search{
        width: 80%;
        text-align: center;
        justify-content: center;
        margin: auto;
    }

    .product_section_search form {
    display: flex;

}

.product_section_search select {
    width: 700px;
    padding-left: 10px;
    padding-right: 10px;
    border-radius: 5px;
}


.product_section_search input[type="submit"] {
    height: 50px;
    border-radius: 30px;
}












</style>
