<div class="cart-container">
    <h2>Your Cart</h2>
    <table class="cart-table">
        <thead>
            <tr>
                <th style="width: 150px;">Product Image</th>
                <th>Product Name</th>
                <th>Product Quantity</th>
                <th>Price</th>
                <th style="width: 150px;">Action</th>
            </tr>
        </thead>
        <tbody>

            <?php $totalprice = 0; ?>

            @foreach ($data as $data)


            <tr>
                <td style="text-align: center;"><img src="{{ asset('productimage/' . $data->image) }}" alt="Product Image"></td>
                <td style="text-align: center;">{{ $data->product_title }}</td>
                <td style="text-align: center;">{{ $data->quantity }}</td>
                <td style="text-align: right;">{{ $data->price }}.00</td>
                <td><button class="btn btn-danger" ><a onclick="return confirm('Are You Sure You Want To Remove {{ $data->product_title }} From The Cart')" href="{{ url('remove_cart',$data->id) }}">Remove</a></button></td>
            </tr>

            <?php $totalprice = $totalprice + $data->price ; ?>
            @endforeach


            <tr>
                <td></td>
                <td></td>
                <td style="text-align: right;">Total Price</td>
                <td style="text-align: right;">{{ $totalprice }}.00</td>
                <td></td>
            </tr>


        </tbody>
    </table>

<div class="proceed">

    <h1>Proceed To Order</h1>

    <a onclick="return confirm('Are You Sure You Want Proceed with this Order')" href="{{ url('cash_order') }}" class="btn btn-success">Cash Payment</a>

    <a href="{{ url('stripe',$totalprice) }}" class="btn btn-success">Card Payment</a>

</div>


</div>
