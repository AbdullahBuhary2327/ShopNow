<header class="header_section">
    <div class="container">
        <nav class="navbar">
            <a class="navbar-brand" href="{{ url('/') }}"><img width="250" src="home/images/shopnow-logo2.png"
                    alt="#" /></a>
            <button class="navbar-toggler" type="button" aria-label="Toggle navigation"></button>
            <div class="navbar-nav">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="{{ url('/') }}">Home </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('show_products_here') }}">Products</a>
                    </li>


                    @if (Route::has('login'))
                    @auth

                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('show_cart') }}">Cart</a>
                    </li>

                    @endauth

                    @endif

                    <form class="form-inline">
                        <button class="btn my-2 my-sm-0 nav_search-btn" type="submit">
                            <i class="fa fa-search" aria-hidden="true"></i>
                        </button>
                    </form>




                </ul>
            </div>
        </nav>
    </div>
</header>
