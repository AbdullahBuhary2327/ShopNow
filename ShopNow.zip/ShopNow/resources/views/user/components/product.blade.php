<section class="product_section layout_padding">
    <div class="container">
       <div class="heading_container heading_center" style="margin-bottom: 50px">
          <h2>
             Our <span>products</span>
          </h2>
       </div>


       <div class="product_section_search">


        <form action="{{ url('product_search') }}" method="GET">
            @csrf

            <select name="search">
                <option selected></option>
                @foreach ($category as $category)
                    <option value="{{ $category->category_name }}">{{ $category->category_name }}</option>
                @endforeach
            </select>

            <input type="submit" value="Search">
        </form>


       </div>

       <div class="row">


        @foreach ($data as $datas)


          <div class="col-sm-6 col-md-4 col-lg-4">
             <div class="box">
                <div class="option_container">
                   <div class="options">
                      <a href="{{ url('product_details', $datas->id) }}" class="option1">
                      Product Details
                      </a>


                      <form action="{{ url('add_cart',$datas->id) }}" method="Post" enctype="multipart/form-data">
                        @csrf
                        <input type="number" name="quantity" class="op-q" value="1" min="1" max="{{ $datas->quantity }}">
                        <input type="submit" value="add to cart">
                      </form>



                   </div>
                </div>
                <div class="img-box">
                    <img  name="image" src="{{ asset('productimage/' . $datas->image) }}" alt="Job 1 Image">
                </div>
                <div class="detail-box">
                   <h5>
                      {{ $datas->title }}
                   </h5>
                   @if ($datas->discount_price!=null)
                   <h6 style="margin-left: 20px; margin-right: 30px; color: red;">
                    {{ $datas->discount_price }}
                 </h6>

                 <h6 style="text-decoration: line-through; color: blue;">
                    {{ $datas->price }}
                 </h6>

                 @else

                 <h6 style="color: blue;">
                    {{ $datas->price }}
                 </h6>


                   @endif

                </div>
             </div>
          </div>

          @endforeach

          <span style="padding-top: 50px">
          {{ $data->appends(Request::all())->links('vendor.pagination.bootstrap-4') }}
        </span>


       </div>
       <div class="btn-box">
          <a href="{{ url('show_products_here') }}">
          View All products
          </a>
       </div>
    </div>
 </section>
