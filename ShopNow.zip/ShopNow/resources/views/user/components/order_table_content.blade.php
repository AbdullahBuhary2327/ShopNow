<div class="cart-container" style="margin-bottom: 50px;">
    <h2>View Your Orders</h2>
    <table class="cart-table">
        <thead>
            <tr>
                <th style="width: 150px;">Product Image</th>
                <th>Product Name</th>
                <th style="width: 250px;">Product Quantity</th>
                <th>Price</th>
                <th>Payment Status</th>
                <th>Delivery Status</th>
                <th>Cancel Order</th>
            </tr>
        </thead>
        <tbody>



            @foreach ($data as $data)


            <tr>
                <td style="text-align: center;"><img src="{{ asset('productimage/' . $data->image) }}" alt="Product Image"></td>
                <td style="text-align: center;">{{ $data->title }}</td>
                <td style="text-align: center;">{{ $data->quantity }}</td>
                <td style="text-align: right;">{{ $data->price }}.00</td>

                @if ($data->payment_status=='Payment Received')

                <td style="text-align: center; font-weight: bold; color: green; text-align:center;"> {{ $data->payment_status }}</td>

                @elseif ($data->payment_status == 'Order Cancelled')

                <td style="text-align: center; font-weight: bold; color: rgb(128, 0, 0); text-align:center;"> {{ $data->payment_status }}</td>

                @else


                <td style="text-align: center; font-weight: bold; color: rgb(17, 0, 255); text-align:center;"> {{ $data->payment_status }}</td>

                @endif

                @if ($data->delivery_status=='Processing')

                <td style="text-align: center; font-weight: bold; color: rgb(255, 94, 0); text-align:center;"> {{ $data->delivery_status }}</td>

                @elseif ($data->delivery_status == 'Order Cancelled')

                <td style="text-align: center; font-weight: bold; color: rgb(128, 0, 0); text-align:center;">{{ $data->delivery_status }}</td>

                @else

                <td style="text-align: center; font-weight: bold; color: green; text-align:center;"> {{ $data->delivery_status }}</td>

                @endif

                @if ($data->payment_status == 'Cash on Delivery')



                <td style="text-align: center;"><a onclick="return confirm('Are You Sure You Want To Cancel This Order Of {{ $data->title }}')" href="{{ url('cancel_order',$data->id) }}" class="btn btn-danger">Cancel</a></td>


                @elseif ($data->delivery_status == 'Order Cancelled')

                <td style="text-align: center; font-weight: bold; color: rgb(128, 0, 0); text-align:center;">Cancelled</td>



                @else

                <td style="text-align: center;">Not Applicable</td>



                @endif

            </tr>


            @endforeach



        </tbody>
    </table>



</div>
