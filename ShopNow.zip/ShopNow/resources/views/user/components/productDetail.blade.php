<div id="product_detail_section" >
    <div class="img-box">
        <img name="image" src="{{ asset('productimage/' . $data->image) }}" alt="Product Image">
    </div>
    <div class="detail-box">
        <h1>{{ $data->title }}</h1>
        <h3>Category: {{ $data->category }}</h3>
        <p>{{ $data->description }}</p>
        <h6 >Stock: {{ $data->quantity }}</h6>


        @if(Auth::check())
            @if(Auth::user()->wishlist()->where('product_id', $data->id)->exists())
                <button  class="btn btn-outline-danger" style="width: 300px; color: black;"><a style="color: black" onclick="return confirm('Are You Sure You Want Delete {{ $data->title }} From Your Wishlist')" href="{{ url('delete_wishlist', $data->id) }}">Delete From wishlist</a> </button>
            @else
                <form action="{{ route('wishlist.add', ['product' => $data->id]) }}" method="POST">
                    @csrf
                    <button onclick="return confirm('Are You Sure You Want Add This To Your Wishlist')" type="submit" class="btn btn-outline-success" style="width: 200px; color: black;">Add To Wishlist</button>
                </form>
            @endif
        @else
            <!-- Display a message or redirect to the login page for guests -->
        @endif



        @if ($data->discount_price!=null)

        <h6 class="discounted">Discounted Price: {{ $data->discount_price }}</h6>
        <h6 class="price">Price: {{ $data->price }}</h6>

        @else

        <h6 class="price2">Price: {{ $data->price }}</h6>

        @endif

        <div style="display: flex; align-items: center;" class="add-to-cart-form">
            <form action="{{ url('add_cart',$data->id) }}" method="Post" enctype="multipart/form-data">
                @csrf
                <input type="number" name="quantity" class="productQuantity-quan" value="1" min="1" max="{{ $data->quantity }}">
                <input type="submit" value="add to cart" class="productQuantity-sub">
              </form>
        </div>


    </div>

</div>
