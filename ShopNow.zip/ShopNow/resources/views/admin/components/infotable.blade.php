
<div class="modern-table-1">
<table class="data-table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Address</th>
        </tr>
    </thead>
    <tbody>
        <tr>

            <td>{{ Auth::guard('web')->user()->name }}</td>
            <td>{{ Auth::guard('web')->user()->email }}</td>
            <td>{{ Auth::guard('web')->user()->phone }}</td>
            <td>{{ Auth::guard('web')->user()->address }}</td>
        </tr>
        <!-- Add more rows as needed -->
    </tbody>
</table>

</div>
