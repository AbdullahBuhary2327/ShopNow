<nav class="sidebar">
    <ul>
        <li><a href="{{ url('/redirect') }}" class="{{ Request::is('redirect') ? 'active-link' : '' }}"><i class="fas fa-home"></i> Home</a></li>

        <li class="{{ Route::is('view_customers') ? 'active' : '' }}">
            <a href="{{ route('view_customers') }}"><i class="fas fa-users"></i> Customers</a>
        </li>


        <li class="{{ Route::is('view_category') ? 'active' : '' }}">
            <a href="{{ route('view_category') }}"><i class="fas fa-list-ul"></i> Category</a>
        </li>


        <li class="">
            <a href="#"><i class="fas fas fa-cubes"></i> Product<i class="fas fa-chevron-down" style="margin-left: 30px;"></i></a>
            <ul class="nested-links">
                <li><a href="{{ route('view-add-product') }}"><i class="fas fa-chevron-right" style="margin-right: 30px;"></i>Add Products</a></li>
                <li><a href="{{ route('view-show-product') }}"><i class="fas fa-chevron-right" style="margin-right: 30px;"></i>Show Products</a></li>
                <!-- Add more nested links as needed -->
            </ul>
        </li>

        <li class="">
            <a href="#"><i class="fas fa-shopping-cart"></i> Orders<i class="fas fa-chevron-down" style="margin-left: 30px;"></i></a>
            <ul class="nested-links">
                <li><a href="{{ url('/show_order') }}"><i class="fas fa-chevron-right" style="margin-right: 30px;"></i>Pending Orders</a></li>
                <li><a href="{{ url('/delivered_order') }}"><i class="fas fa-chevron-right" style="margin-right: 30px;"></i>Delivered Orders</a></li>
                <li><a href="{{ url('/cancelled_order') }}"><i class="fas fa-chevron-right" style="margin-right: 30px;"></i>Cancelled Orders</a></li>
                <!-- Add more nested links as needed -->
            </ul>
        </li>



    </ul>
</nav>
