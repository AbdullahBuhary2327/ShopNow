<div class="title-category">
    <h1>Update Customers</h1>
</div>

<div class="sesseion-msg">

@if(session('message'))
    <div class="alert alert-success">
        {{ session('message') }}
    </div>
@endif

@if(session('error'))
    <div class="alert alert-danger"> <!-- Changed to alert-danger for error messages -->
        {{ session('error') }}
    </div>
@endif

</div>


<div class="category-form">
    <form action="{{ route('update-user',$data->id) }}" method="POST" >
        @csrf

        <label for="name">Name</label>
        <input type="text" id="name" name="name" value="{{ $data->name }}" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="{{ $data->email }}" required>

        <label for="phone">Phone</label>
        <input type="number" id="phone" name="phone" value="{{ $data->phone }}" required>

        <label for="address">Address</label>
        <input type="text" id="address" name="address" value="{{ $data->address }}" required>





        <button type="submit">Update User</button>
    </form>
</div>

<h1 style="text-align: center; margin-top: 80px;">Update Password</h1>
<div class="category-form">
    <form action="{{ route('update-user-password',$data->id) }}" method="POST" >
        @csrf

        <label for="cpassword">Current Password</label>
        <input type="text" id="cpassword" name="cpassword" value="{{ $data->password }}" disabled>

        <label for="password">New Password</label>
        <input type="text" id="password" name="password" placeholder="Enter New Password" required>







        <button type="submit">Update Password</button>
    </form>
</div>







<h6>.</h6>
