<div class="title-category">
    <h1>Add Customers</h1>
</div>

<div class="sesseion-msg">

@if(session('message'))
    <div class="alert alert-success">
        {{ session('message') }}
    </div>
@endif

@if(session('error'))
    <div class="alert alert-danger"> <!-- Changed to alert-danger for error messages -->
        {{ session('error') }}
    </div>
@endif

</div>


<div class="category-form">
    <form action="{{ route('add-user') }}" method="POST" >
        @csrf

        <label for="name">Name</label>
        <input type="text" id="name" name="name" placeholder="Enter User name" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="Enter Email Address" required>

        <label for="phone">Phone</label>
        <input type="number" id="phone" name="phone" placeholder="Enter Phone Number" required>

        <label for="address">Address</label>
        <input type="text" id="address" name="address" placeholder="Enter address" required>

        <label for="password">Password</label>
        <input type="text" id="password" name="password" placeholder="Enter Password" required>



        <button type="submit">Add User</button>
    </form>
</div>


<h1 style="text-align: center; margin-top: 70px;">Customer Details</h1>

<div class="modern-table" style="text-align: center">
    <table class="data-table-2">
        <thead>
            <tr>

                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>

                <th style="width: 90px">Delete</th>
                <th style="width: 90px">Update</th>
            </tr>
        </thead>
        <tbody>

            @foreach ($data as $data)


            <tr>
                <td>{{ $data->name }}</td>
                <td>{{ $data->email }}</td>
                <td>{{ $data->phone }}</td>
                <td>{{ $data->address }}</td>
                <td><a onclick="return confirm('Are You Sure You Want To Delete {{ $data->name }}')" href="{{ route('delete-user',$data->id) }}" class="btn btn-danger" style="width: 80%;">Delete</a></td>
                <td><a onclick="return confirm('Are You Sure You Want To Update {{ $data->name }}')" href="{{ route('view-update-user',$data->id) }}" class="btn btn-warning" style="width: 80%;">Update</a></td>



            </tr>

            @endforeach
            <!-- Add more rows as needed -->
        </tbody>
    </table>
</div>




<h6>.</h6>
