<div class="title-category">
    <h1>Add Categories</h1>
</div>

<div class="sesseion-msg">

@if(session('message'))
    <div class="alert alert-success">
        {{ session('message') }}
    </div>
@endif

@if(session('error'))
    <div class="alert alert-danger"> <!-- Changed to alert-danger for error messages -->
        {{ session('error') }}
    </div>
@endif

</div>


<div class="category-form">
    <form action="{{ route('add-category') }}" method="POST" >
        @csrf

        <label for="category_name">Category Name</label>
        <input type="text" id="category_name" name="category_name" placeholder="Enter category name" required>



        <button type="submit">Add Category</button>
    </form>
</div>



<div class="modern-table" style="margin-top: 50px;">
    <table class="data-table-2">
        <thead>
            <tr>

                <th>Category Name</th>

                <th style="width: 110px">Delete</th>
            </tr>
        </thead>
        <tbody>

            @foreach ($data as $data)


            <tr>
                <td>{{ $data->category_name }}</td>
                <td><a onclick="return confirm('Are You Sure You Want To Delete {{ $data->category_name }}')" href="{{ route('delete-category',$data->id) }}" class="btn btn-danger" style="width: 80%;">Delete</a></td>
            </tr>

            @endforeach
            <!-- Add more rows as needed -->
        </tbody>
    </table>
</div>




<h6>.</h6>
