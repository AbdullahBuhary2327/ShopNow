<div class="title-category">
    <h1>Show Product</h1>
</div>


<div class="search_button_section">
    <form action="{{ url('search3') }}" method="GET">

        @csrf

        <input type="text" name="search" placeholder="Search Here">
        <input type="submit" value="Search">
    </form>
</div>


<div class="modern-table-6">
    <table class="data-table-6">
        <thead>
            <tr>

                <th>Product Name</th>
                <th style="width: 200px;">Product Description</th>
                <th>Product Image</th>
                <th>Category Name</th>
                <th>Quantity</th>
                <th>Product Price</th>
                <th>Discounted Price</th>
                <th style="width: 210px">Update</th>
                <th style="width: 210px">Delete</th>
            </tr>
        </thead>
        <tbody>

            @forelse ($data as $data)


            <tr>
                <td>{{ $data->title }}</td>
                <td>{{ $data->description }}</td>
                <td><img src="{{ asset('productimage/' . $data->image) }}" width="100px" height="100px"></td>
                <td>{{ $data->category }}</td>
                <td>{{ $data->quantity }}</td>
                <td>{{ $data->price }}</td>
                <td>{{ $data->discount_price }}</td>
                <td><a href="{{ route('view-update-product',$data->id) }}" class="btn btn-warning" style="width: 100px;">Update</a></td>
                <td><a onclick="return confirm('Are You Sure You Want To Delete {{ $data->title }}')" href="{{ route('delete-product',$data->id) }}" class="btn btn-danger" style="width: 100px;">Delete</a></td>
            </tr>

            @empty

            <tr><td colspan="16">No Data Found</td></tr>

            @endforelse
            <!-- Add more rows as needed -->
        </tbody>
    </table>
</div>










<h6>.</h6>
