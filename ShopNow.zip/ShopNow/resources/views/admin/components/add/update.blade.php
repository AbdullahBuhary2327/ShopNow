<div class="title-category">
    <h1>Update Product</h1>
</div>


<div class="category-form" style="margin-bottom: 100px;">
    <form action="{{ route('update-product',$data->id) }}" method="POST" enctype="multipart/form-data">
        @csrf

        <label for="title">Product Name</label>
        <input type="text" id="title" name="title" value="{{ $data->title }}" required>

        <label for="description">Product Description</label>
        <input type="text" id="description" name="description" value="{{ $data->description }}" required>

        <label for="category">Category Name</label>
        <select id="category" name="category" required>
            <option value="{{ $data->category }}" selected="">{{ $data->category }}</option>
            @foreach ($item as $item)
            <option value="{{ $item->category_name }}">{{ $item->category_name }}</option>
            @endforeach

        </select>

        <label for="quantity">Product quantity</label>
        <input type="number" id="quantity" name="quantity" value="{{ $data->quantity }}" required>

        <label for="price">Product Price</label>
        <input type="number" id="price" name="price" value="{{ $data->price }}" required>

        <label for="discount">Discount</label>
        <input type="number" id="discount" name="discount" value="{{ $data->discount_price }}">





        <button type="submit">Update Product</button>
    </form>
</div>

<div class="title-category">
    <h1>Update Product Image</h1>
</div>

<div class="category-form">
    <form action="{{ route('update-product-image',$data->id) }}" method="POST" enctype="multipart/form-data">
        @csrf

        <label for="image">Old Image:</label>
    <img width="250px" src="/productimage/{{ $data->image }}" alt="" style="margin-bottom: 20px">

    <label for="image">New Image:</label>
    <input type="file" id="image" name="image" value="{{ $data->image }}" required>


        <button type="submit">Update Image</button>
    </form>
</div>


<h6 style="margin-top: 100px;">.</h6>
