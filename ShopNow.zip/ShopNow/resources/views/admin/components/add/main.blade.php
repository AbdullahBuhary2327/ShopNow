<div class="title-category">
    <h1>Add Product</h1>
</div>

<div class="sesseion-msg">

@if(session('message'))
    <div class="alert alert-success">
        {{ session('message') }}
    </div>
@endif

@if(session('error'))
    <div class="alert alert-danger"> <!-- Changed to alert-danger for error messages -->
        {{ session('error') }}
    </div>
@endif

</div>


<div class="category-form">
    <form action="{{ route('add-product') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <label for="title">Product Name</label>
        <input type="text" id="title" name="title" placeholder="Enter Product name" required>

        <label for="description">Product Description</label>
        <input type="text" id="description" name="description" placeholder="Enter Product description" required>

        <label for="image">Product Image</label>
        <input type="file" id="image" name="image" required>

        <label for="category">Category Name</label>
        <select id="category" name="category" required>
            <option value="" selected="">Select a Category</option>
            @foreach ($data as $data)
            <option value="{{ $data->category_name }}">{{ $data->category_name }}</option>
            @endforeach

        </select>

        <label for="quantity">Product quantity</label>
        <input type="number" id="quantity" name="quantity" placeholder="Enter Product quantity" required>

        <label for="price">Product Price</label>
        <input type="number" id="price" name="price" placeholder="Enter Product Price" required>

        <label for="discount">Discount</label>
        <input type="number" id="discount" name="discount" placeholder="Enter Discounted Price">





        <button type="submit">Add Product</button>
    </form>
</div>








<h6>.</h6>




</div>
</div>



@include('admin.components.script')
