<script>
    $(document).ready(function() {
        // Toggle nested links on click
        $('.sidebar > ul > li').click(function() {
            $(this).toggleClass('active');
            $(this).find('.nested-links').slideToggle();
        });
    });
</script>
