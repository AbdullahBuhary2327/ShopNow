<div class="title-category">
    <h1>Cancelled Orders</h1>
</div>



<div class="modern-table-4" style="margin-left: 30px">
    <table class="data-table-4">
        <thead>
            <tr>

                <th>Customer Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Payment Status</th>
                <th>Delivery Status</th>
                <th>Image</th>
            </tr>
        </thead>
        <tbody>



            @forelse ($data as $data)



            <tr>
                <td>{{ $data->name }}</td>
                <td>{{ $data->email }}</td>
                <td>{{ $data->phone }}</td>
                <td>{{ $data->address }}</td>
                <td>{{ $data->title }}</td>
                <td>{{ $data->quantity }}</td>
                <td>{{ $data->price }}</td>
                <td style="color: red;">{{ $data->payment_status }}</td>
                <td style="color: red;">{{ $data->delivery_status }}</td>
                <td><img src="{{ asset('productimage/' . $data->image) }}" width="100px" height="100px"></td>




            </tr>

            @empty

            <tr><td colspan="16">No Data Found</td></tr>

            @endforelse


        </tbody>
    </table>
</div>










<h6>.</h6>
