<div class="title-category">
    <h1>Delivered Orders</h1>
</div>


<div class="search_button_section">
    <form action="{{ url('search2') }}" method="GET">

        @csrf

        <input type="text" name="search" placeholder="Search Here">
        <input type="submit" value="Search">
    </form>
</div>

<div class="modern-table-4" style="margin-left: 30px">
    <table class="data-table-4">
        <thead>
            <tr>

                <th>Customer Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Payment Status</th>
                <th>Delivery Status</th>
                <th>Image</th>
                <th style="width: 100px;">Delivered</th>
            </tr>
        </thead>
        <tbody>



            @forelse ($data as $data)



            <tr>
                <td>{{ $data->name }}</td>
                <td>{{ $data->email }}</td>
                <td>{{ $data->phone }}</td>
                <td>{{ $data->address }}</td>
                <td>{{ $data->title }}</td>
                <td>{{ $data->quantity }}</td>
                <td>{{ $data->price }}</td>
                <td>{{ $data->payment_status }}</td>
                <td>{{ $data->delivery_status }}</td>
                <td><img src="{{ asset('productimage/' . $data->image) }}" width="100px" height="100px"></td>
                @if ($data->delivery_status == 'Processing')
                {
                <td style="width: 150px;">

                        <button class="btn btn-danger"><a onclick="return confirm('Are You Sure The {{ $data->title }} is Delivered')"
                            href="{{ url('/updatestatus',$data->id) }}" >Delivered?</a></button>
                </td>
                }

                @else
                {
                    <td style="width: 150px;"><img width="50px" style="margin-left: 10px;" src="{{ asset('yes.png') }}" alt=""></td>
                }

                @endif



            </tr>

            @empty

            <tr><td colspan="16">No Data Found</td></tr>

            @endforelse


        </tbody>
    </table>
</div>










<h6>.</h6>
