<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});


Route::get('/',[HomeController::class,'index'])->name('index');

Route::post('/loginUser',[HomeController::class,'loginUser'])->name('loginUser');

Route::post('/loginAdmin',[AdminController::class,'loginAdmin'])->name('loginAdmin');

Route::get('/adminIndex',[AdminController::class,'adminIndex'])->name('adminIndex');

Route::get('/redirect',[HomeController::class,'redirect'])->name('redirect');

Route::get('/logoutUser', [HomeController::class, 'logoutUser'])->name('logoutUser');

Route::get('/product_details/{id}',[HomeController::class,'product_details']);

Route::post('/add_cart/{id}',[HomeController::class,'add_cart']);

Route::get('/show_cart',[HomeController::class,'show_cart']);

Route::get('/remove_cart/{id}',[HomeController::class,'remove_cart']);

Route::get('/cash_order',[HomeController::class,'cash_order']);

Route::get('/show_order', [AdminController::class, 'show_order']);

Route::get('/delivered_order', [AdminController::class, 'delivered_order']);

Route::get('/cancelled_order', [AdminController::class, 'cancelled_order']);

Route::get('/stripe/{totalprice}', [HomeController::class, 'stripe']);

Route::post('stripe/{totalprice}', [HomeController::class,'stripePost'])->name('stripe.post');

Route::get('/updatestatus/{id}', [AdminController::class, 'updatestatus']);

Route::get('/print_pdf/{id}', [AdminController::class, 'print_pdf']);

Route::get('/search', [AdminController::class, 'searchdata']);

Route::get('/search2', [AdminController::class, 'searchdata2']);

Route::get('/search3', [AdminController::class, 'searchdata3']);

Route::get('/show_products_here', [HomeController::class, 'show_products_here']);

Route::get('/show_wishlist_here', [HomeController::class, 'show_wishlist_here']);

Route::get('/show_order_here', [HomeController::class, 'show_order_here']);

Route::get('/cancel_order/{id}', [HomeController::class, 'cancel_order']);

Route::get('/product_search', [HomeController::class, 'product_search']);

Route::get('/product_search2', [HomeController::class, 'product_search2']);

Route::post('/add-to-wishlist/{product}', [HomeController::class, 'addToWishlist'])->name('wishlist.add');

Route::get('delete_wishlist/{id}',[HomeController::class,'delete_wishlist'])->name('delete_wishlist');



