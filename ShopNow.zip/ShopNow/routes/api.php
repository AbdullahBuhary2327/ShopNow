<?php

use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


Route::get('view_category',[CategoryController::class,'view_category'])->name('view_category');



Route::get('view_customers',[UserController::class,'index'])->name('view_customers');

Route::post('add-category',[CategoryController::class,'store'])->name('add-category');

Route::post('add-user',[UserController::class,'store'])->name('add-user');

Route::get('delete-category/{id}',[CategoryController::class,'destroy'])->name('delete-category');

Route::get('delete-user/{id}',[UserController::class,'destroy'])->name('delete-user');

Route::get('view-add-product',[ProductController::class,'index'])->name('view-add-product');

Route::get('view-show-product',[ProductController::class,'show'])->name('view-show-product');

Route::post('add-product',[ProductController::class,'store'])->name('add-product');

Route::get('view-update-product/{id}',[ProductController::class,'view_update_product'])->name('view-update-product');

Route::get('view-update-user/{id}',[UserController::class,'show'])->name('view-update-user');

Route::post('update-product/{id}',[ProductController::class,'update'])->name('update-product');

Route::post('update-user-password/{id}',[UserController::class,'update_password'])->name('update-user-password');

Route::post('update-user/{id}',[UserController::class,'update'])->name('update-user');

Route::post('update-product-image/{id}',[ProductController::class,'update_image'])->name('update-product-image');

Route::get('delete-product/{id}',[ProductController::class,'destroy'])->name('delete-product');
